from args import args
from pymatching import Matching
import numpy as np
import torch
import time
import sys
from os.path import abspath, dirname
sys.path.append(abspath(dirname(__file__)).strip('decoding'))
print(sys.path.append(abspath(dirname(__file__)).strip('decoding')))

from module.codes import Loading_code
from module.mod2 import mod2
from module.utils import read_code, Hx_Hz, Errormodel

import os
os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'

# d=5 , k=1 ,seed=0,  c_type=sur

d, k, seed, c_type = args.d, args.k, args.seed, args.c_type
d = 9
c_type= 'rsur'
# trials = 10000
trials = args.trials
# device= 'cuda:0' dtype=float32
device, dtype = 'cpu', torch.float64
# e_model = dep
e_model = args.e_model
# error_seed= 51697
error_seed = args.error_seed
mod2 = mod2(device=device, dtype=dtype)

info = read_code(d, k, seed, c_type=c_type)
code = Loading_code(info)
n = code.n
PCM = code.PCM.cpu().numpy()
#print(PCM)
hx, hz = Hx_Hz(code.g_stabilizer)
hx, hz = hx.cpu().numpy(), hx.cpu().numpy()
#print(hx)
#print(hz)

l1 = mod2.rep(code.logical_opt).int().cpu().numpy()
l = np.zeros_like(l1)
l[:, :n], l[:, n:] = l1[:, n:], l1[:, :n]
#print(l)

print(n,d,k,seed,c_type,trials,e_model,error_seed)


L = []
error_rate = torch.linspace(0.06,0.18,13)
# error_rate = torch.tensor([0.01])
print(error_rate)
tt = torch.zeros(len(error_rate))
for i in range(len(error_rate)):
    '''generate error'''
    E = Errormodel(error_rate[i], e_model=e_model)
    errors = E.generate_error(code.n,  m=trials, seed=error_seed)
    # dep代表去极化噪声
    if e_model == 'dep':
        er = 2*error_rate[i]/3

    elif e_model == 'dep2':
        er = 8*error_rate[i]/15

    weights = torch.ones(2*code.n)*torch.log((1-er)/er)
    Decoder = Matching(PCM, weights=weights)
    syndrome = mod2.commute(errors, code.g_stabilizer)
    pe = E.pure(code.pure_es, syndrome,device=device, dtype=dtype)
    error = mod2.rep(errors).squeeze().int().cpu().numpy()
    syndrome = syndrome.cpu().numpy()

    correct_number = 0
    t = 0
    for j in range(trials):
        e = error[j]
        s = syndrome[j]

        t1 = time.time()
        #print(s)
        recover = Decoder.decode(s)
        check = (e + recover)%2
        s = np.sum((check @ l.T) %2)
        t2 = time.time()
        t = t+(t2-t1)
        if s == 0:
            correct_number+=1
        
    lorate = 1 - correct_number/trials
    ta = t/trials
    print(lorate)
    print(ta)
    tt[i] = ta
    L.append(lorate)
print(L)
print(tt.mean().item(), tt.std().item())    




